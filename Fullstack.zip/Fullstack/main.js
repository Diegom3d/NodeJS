const express=require('express');
const app=express();
const port=3001;
var cors=require('cors');
const sql=require('mssql');

app.get('/',(req,res)=>{
    res.send('Hola, el servidor esta funcionando');

});
app.listen(port, ()=>{
    console.log(`El servidor esta en el puerto ${port}`)});

app.use(express.json());
app.use(cors());
    

const config={
    user:'sa',
    password:'smsdiego',
    server:'DESKTOP-VCIMGEP\\SQLEXPRESS',   
    database:'FullStack',
    options:{
        port:1433,
        encrypt:false,
    },

};

//connect to the database
sql.connect(config,(err)=>{
    if(err){
console.log('No se conecto correctamnete', err);
    }
    else {
console.log('Conexion exitosa');
    }
});

//CONSULTAS TABLA COCHES

app.post('/insert/Cliente', async(req, res)=>{
    try{
    //Ver que vamos a mandar al req.body
        console.log(req.body)
        const{Nombre, Apellido}=req.body;
//Mandar el insert a la BD
        const result = await sql.query `INSERT INTO Cliente (Nombre, Apellido) VALUES (${Nombre}, ${Apellido})`;

        res.json({message: 'Registro del Cliente se agrego bien'});

    }catch(error){ //Atrapar el error 

        console.error('Tienes el siguiente error: ', error);
        res.status(500).json({error:'Internal Server Error'});
    }
});
//PENDIENTE ACTIVIDAD PASADA
app.post('/insert/Coche', async(req, res)=>{
    try{
    //Ver que vamos a mandar al req.body
        console.log(req.body)
        const{NomCoche, Año}=req.body;
//Mandar el insert a la BD
        const result = await sql.query `INSERT INTO Coche (NomCoche, Año) VALUES (${NomCoche}, ${Año})`;


        res.json({message: 'Registro  de Coche se agrego bien'});

    }catch(error){ //Atrapar el error 

        console.error('Tienes el siguiente error master: ', error);
        res.status(500).json({error:'Internal Server Error'});
    }
});

app.post('/insert/Pais', async(req, res)=>{
    try{
    //Ver que vamos a mandar al req.body
        console.log(req.body)
        const{Nombre, Marca}=req.body;
//Mandar el insert a la BD
        const result = await sql.query `INSERT INTO Pais (Nombre, Ciudad) VALUES (${Nombre}, ${Marca})`;


        res.json({message: 'Registro de Pais se agrego bien'});

    }catch(error){ //Atrapar el error 

        console.error('Tienes el siguiente error master: ', error);
        res.status(500).json({error:'Internal Server Error'});
    }
});


app.get('/select/Pais', async (req, res) => {
    try {
      const result = await sql.query`SELECT * FROM Pais`;
      if (result.recordset.length === 0) {
        res.status(404).json({ message: 'Registro no encontrado' });
      } else {
        res.json(result.recordset[0]);
      }
    } catch (error) {
      console.error('Error: ', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
    });

    app.get('/select/Cliente', async (req, res) => {
        try {
          const result = await sql.query`SELECT * FROM Cliente`;
          if (result.recordset.length === 0) {
            res.status(404).json({ message: 'Registro no encontrado' });
          } else {
            res.json(result.recordset[0]);
          }
        } catch (error) {
          console.error('Error: ', error);
          res.status(500).json({ error: 'Internal Server Error' });
        }
        });
    
app.get('/select/Coche', async (req, res) => {
    try {
      const result = await sql.query`SELECT * FROM Coche`;
      if (result.recordset.length === 0) {
        res.status(404).json({ message: 'Registro no encontrado' });
      } else {
        res.json(result.recordset[0]);
      }
    } catch (error) {
      console.error('Error: ', error);
      res.status(500).json({ error: 'Internal Server Error' });
    }
    });

